---> Game Rules <---

The game has 2 players.
   
   - Player 1 and Player 2

In each turn, a player can roll the dices as many times as he whishes.
   
   - If the player rolls a "1", all his CURRENT score gets lost.
   - If the player rolls a double "6", all the scores are lost from "CURRENT" and "PLAYER".

ADD SCORE 
   
   - Click on the "ADD SCORE" button once you set the desired WINNING SCORE.

NEW GAME
    
   - Starts a new game.
    
ROLL DICE
    
   - Rolls the dices for the ACTIVE player.
    
HOLD
   
   - Holds the values from the CURRENT.


-----> Have fun with the GAME <-------
    

Special thanks to Luca Greco & Cosmin Campian!